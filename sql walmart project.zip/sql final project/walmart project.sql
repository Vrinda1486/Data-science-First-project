TASK 1
with highest_sales as 
(select Branch, round(sum(Total),2) as Total_sales,monthname(Date_col) as months from walmartsales group by Branch, months order by Total_sales desc ),
top_branch as
(select Branch, Total_sales, months, rank() over(partition by Branch order by Total_sales)as ranked from highest_sales)
select Branch, Total_sales, months from top_branch ;
TASK 2
with Profit_per_productline as
(select Branch,Product_line, round(sum(gross_income-cogs),2) as Profit from walmartsales group by Product_line, branch order by branch),
products_ranking as
(select Branch, Profit, Product_line, rank() over(partition by Branch order by Profit asc) As ranking from Profit_per_productline)
select Branch,Product_line as Most_profitable, Profit as Max_profit from products_ranking where ranking = 1;
TASK 3
with spending_behav as
(select Customer_ID, ROUND(sum(Total),2) as Total_pur_amount from walmartsales group by Customer_ID order by Customer_ID)
select Customer_ID, Total_pur_amount, case when Total_pur_amount<=20000 then 'Low Spenders'
when Total_pur_amount<=25000 then 'Medium Spenders'
else 'High Spenders'
end as segmentation from spending_behav; 
TASK 4
with FilteredSales as 
   (select
        Customer_ID, 
        Product_line, 
        Total as Trans_Total, 
        round(avg(Total) over (partition by Product_line), 2) as Product_line_avg,
        round((Total - avg(Total) over (partition by Product_line)), 2) as Difference
    from walmartsales)
select Customer_ID, Product_line, Trans_Total, Product_line_avg, Difference,
    case when Trans_Total >Product_line_avg * 1.50 then 'High'
        when Trans_Total < Product_line_avg * 0.50 then 'Low'
        else 'Normal'
    end as Anomaly_Type
from FilteredSales
where Trans_Total not between
  Product_line_avg * 0.50
    and
   Product_line_avg * 1.50;
TASK 5
with payment_city as
(select payment, city, count(*) as payment_count from walmartsales group by city, payment),
ranked_payments as (select  payment, city, payment_count, rank() over(partition by city order by payment_count desc) as ranking from payment_city)
select payment, city, payment_count from ranked_payments where ranking =1;
TASK 6
with monthly_sales as
(select Gender, monthname(Date_col) as months,ROUND(sum(Total),2) as Total_sales from walmartsales group by Gender,months)
select * from monthly_sales order by Total_sales desc;
TASK 7
with bestproductline as
(select Product_line, Customer_type, round(sum(total),2) as Maxsales 
from walmartsales group by Customer_type, Product_line),
ranking as
(select Product_line, Customer_type, Maxsales,rank() over(partition by Customer_type order by Maxsales desc) as ranked from bestproductline)
select Product_line,Customer_type,Maxsales, ranked from ranking where ranked=1;
TASK 8
select Customer_ID, Date_col, count(Customer_ID) as repeat_purchases from walmartsales where day(Date_col)<=30 group by Customer_ID, Date_col having count(Customer_ID)>1 ;
TASK 9
Select Customer_ID, round(sum(Total),2) as Sales_Volume from walmartsales group by Customer_ID order by Sales_Volume desc limit 5 ;
Task 10
select dayname(Date_col) as days, round(sum(Total),2) as sales from walmartsales group by days order by sales desc;

